# Component Checklist

## Foundation
- [x] ClickHouse
- [x] ClickHouse Keeper
- [x] NATS JetStream
- [x] Grafana
- [x] Prometheus
- [x] Vector

## Collection
- [ ] Fluent Bit
- [ ] Windows event collection approach
- [ ] syslog input plan
- [ ] test generator plan

## Ingestion / Normalization
- [ ] canonical event schema
- [ ] Vector transforms
- [ ] local sample pipeline
- [ ] schema versioning

## Transport
- [ ] NATS subject/stream naming
- [ ] retention rules
- [ ] replay strategy

## Storage
- [ ] ClickHouse database
- [ ] events table
- [ ] partition strategy
- [ ] retention policy
- [ ] sample query set
