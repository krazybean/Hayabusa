# MVP Plan

## Objective

Build a local, runnable starter stack that proves:
- services can start together
- config layout is stable
- observability tools are reachable
- ClickHouse exists as the future event store
- Vector exists as the future ingestion layer
- NATS exists as the future transport layer

## Phase 1: Local foundation

Deliver:
- Docker Compose stack
- ClickHouse
- ClickHouse Keeper
- NATS JetStream
- Grafana
- Prometheus
- Vector

## Phase 2: Basic ingestion path

Deliver:
- Vector reads a local demo source
- Vector writes to stdout or a temporary sink
- optionally add ClickHouse output after validation

## Phase 3: First storage integration

Deliver:
- create a ClickHouse database
- add a simple events table
- route a basic normalized stream into ClickHouse

## Phase 4: Metrics and dashboards

Deliver:
- Prometheus scrape config
- Grafana datasource provisioning

## Phase 5: Detection placeholder

Deliver:
- repo structure for future detection engine
- rules directory in YAML
