# Open Questions

- What is the canonical normalized event schema?
- Should Vector be both local generator and central aggregator in MVP?
- Is NATS required from day one, or only after the first direct Vector -> ClickHouse flow works?
- What is the first ClickHouse table schema?
- Should the first detection engine be Go or Python?
- Should bootstrap alerting use Alertmanager or a custom service later?
