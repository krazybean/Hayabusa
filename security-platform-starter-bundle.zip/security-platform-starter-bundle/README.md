# Security Platform Starter Bundle

This repository is a starter scaffold for a self-hosted, mostly offline, FOSS-first security telemetry platform intended as a modular alternative to Wazuh.

## Goals

- Self-hosted
- Mostly offline
- FOSS-first
- Docker Compose first
- Cluster-ready later
- YAML as the source of truth for human-authored config
- One service per container
- Clear separation between infrastructure, ingestion, storage, detection, alerting, and UI

## Initial chosen stack

- ClickHouse
- ClickHouse Keeper
- NATS JetStream
- Vector
- Grafana
- Prometheus

## Initial local MVP

```text
Vector -> ClickHouse -> Grafana
                  \-> Detection engine (later)
Prometheus -> Grafana
```

NATS JetStream and ClickHouse Keeper are included in the project structure now so the repo can evolve cleanly toward clustering and buffering, even if the very first run is single-node.

## Repository layout

```text
.
├── .codex/
├── configs/
│   ├── environments/
│   ├── global/
│   ├── grafana/
│   ├── prometheus/
│   ├── rules/
│   └── vector/
├── docs/
├── scripts/
├── AGENTS.md
├── docker-compose.yml
└── README.md
```

## Quick start

1. Copy this bundle into your repo.
2. Review `AGENTS.md` and `docs/architecture.md`.
3. Start the local stack:

```bash
docker compose up -d
```

4. Open:
- Grafana: `http://localhost:3000`
- Prometheus: `http://localhost:9090`
- ClickHouse HTTP: `http://localhost:8123`
- NATS monitoring: `http://localhost:8222`

## First Codex task

Use this prompt in Codex:

```text
Read README.md, AGENTS.md, docs/architecture.md, and docs/mvp-plan.md.
Improve this local Docker Compose scaffold into a runnable MVP for:
- ClickHouse
- ClickHouse Keeper
- NATS JetStream
- Vector
- Grafana
- Prometheus

Constraints:
- self-hosted
- mostly offline
- FOSS-first
- Docker Compose only
- YAML as source-of-truth config
- no Kubernetes
- no OpenSearch
- no cloud dependencies

Then:
- validate mounted paths
- improve health checks
- add comments explaining each service
- keep the structure modular for later clustering
```

## Notes

- Secrets should not live in YAML.
- Use environment variables or Docker secrets for sensitive values.
- Keep configs version-controlled.
- Treat this repo as a control plane plus local deployment skeleton.
